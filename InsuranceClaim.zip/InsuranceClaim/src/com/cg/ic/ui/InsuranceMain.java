package com.cg.ic.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.ic.bean.Account;
import com.cg.ic.bean.Claim;
import com.cg.ic.bean.Policy;
import com.cg.ic.bean.PolicyDetails;
import com.cg.ic.bean.UserRole;
import com.cg.ic.service.IInsuranceService;
import com.cg.ic.service.InsuranceServiceImpl;

public class InsuranceMain {

	static Account account;
	static Claim claim;
	static Policy policy;
	static PolicyDetails pDetails;
	static UserRole uRole;
	
	static IInsuranceService service;
	static Scanner sc=new Scanner(System.in);
	
	
	public static void main(String[] args) throws SQLException, Exception {
		
		uRole=new UserRole();
		
		/*String role=null;
		System.out.println("Login user");
		System.out.println("Enter user name");
		//String name=uRole.setUserName(sc.next());
		System.out.println("Enter password");
		uRole.setPassword(sc.next());
		service=new InsuranceServiceImpl();
		//role=service.verifyUser(name,pass);
		
		if(role!=null)
		{
			
			switch(role)
			{
			case "ADMIN12345":
				System.out.println("Admin Menu");
				System.out.println("1.user creation");
				System.out.println("2.claim creation");
				System.out.println("3.view claim");
				System.out.println("4.report generation");
				System.out.println("----------------------");
				System.out.println("enter an operation");
				int x=sc.nextInt();
				switch(x)
				{
				case 1:System.out.println("create user");
				System.out.println("enter user name");
				//name=sc.next(uRole.getUserName());
				
				
				}
			}
			
		}
		
		*/
		
		Policy policy=new Policy();
		
		
		String str1=service.getPolicyDetails();
		
		
		
	}
	
}
