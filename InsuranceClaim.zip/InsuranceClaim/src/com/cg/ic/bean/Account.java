package com.cg.ic.bean;

public class Account {

	private String userName;
	private int accountNumber;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	@Override
	public String toString() {
		return "Account [userName=" + userName + ", accountNumber=" + accountNumber + "]";
	}
	
	
	
}
