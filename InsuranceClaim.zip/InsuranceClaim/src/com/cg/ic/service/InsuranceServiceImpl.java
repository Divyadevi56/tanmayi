package com.cg.ic.service;

import java.sql.SQLException;

import com.cg.ic.bean.UserRole;
import com.cg.ic.dao.IInsuranceDao;
import com.cg.ic.dao.InsuranceDaoImpl;

public class InsuranceServiceImpl implements IInsuranceService {

	
	public String verifyUser(String name, String pass) throws SQLException, Exception {
	   
		IInsuranceDao dao=new InsuranceDaoImpl();
		return  dao.verifyUser(name,pass);
	}


	public String getPolicyDetails() throws Exception {
		IInsuranceDao dao=new InsuranceDaoImpl();
		return dao.getPolicyDetails();
	}

}
