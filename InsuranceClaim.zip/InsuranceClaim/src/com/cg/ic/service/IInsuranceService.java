package com.cg.ic.service;

import java.sql.SQLException;

import com.cg.ic.bean.UserRole;

public interface IInsuranceService {

	String verifyUser(String name, String pass) throws SQLException, Exception;

	String getPolicyDetails() throws Exception;

}
