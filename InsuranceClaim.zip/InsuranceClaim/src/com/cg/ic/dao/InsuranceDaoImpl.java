package com.cg.ic.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.ic.bean.UserRole;
import com.cg.ic.util.DBConnection;

public class InsuranceDaoImpl implements IInsuranceDao{

	PreparedStatement ps;
	ResultSet rs;
	public String verifyUser(String name, String pass) throws Exception {
		
		
		/*Connection con=DBConnection.getConnection();
		UserRole role=new UserRole();
		
		ps=con.prepareStatement("select * from user_role");
		rs=ps.executeQuery();
		 name=rs.getString(1);
		pass=rs.getString(2);
		String urole=rs.getString(3);
		 
		*/
		return null;
	}

	public String getPolicyDetails() throws Exception {

		int n1=0;
		int n2=0;
		int n3=0;
		
		Connection con=DBConnection.getConnection();
		
		ps=con.prepareStatement("select username from user_role");
		
		 rs=ps.executeQuery();
		 String name=rs.getString(1);
	
		 ps=con.prepareStatement("select * from policy where accountnumber=(select accountnumber from account where username=?)");	
		 ps.setString(1,name);
		 rs=ps.executeQuery();
		while(rs.next())
		{
			n1=rs.getInt(1);
			n2=rs.getInt(2);
			n3=rs.getInt(3);
		}
		 
		 
		 
		 return null;
	}

}
