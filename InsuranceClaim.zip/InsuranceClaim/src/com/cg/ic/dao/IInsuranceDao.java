package com.cg.ic.dao;

import java.sql.SQLException;

import com.cg.ic.bean.UserRole;

public interface IInsuranceDao {

	String verifyUser(String name, String pass) throws SQLException, Exception;

	String getPolicyDetails() throws Exception;

}
